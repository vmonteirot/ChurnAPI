package com.challenge.churn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChurnApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
